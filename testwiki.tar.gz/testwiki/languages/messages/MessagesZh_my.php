<?php
/** ‪Chinese (Malaysia)‬ (‪中文(马来西亚)‬)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'zh-sg';
