<?php
/** फ़ीजी हिन्दी (फ़ीजी हिन्दी)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Girmitya
 * @author Thakurji
 */

$messages = array(
'talkpagelinktext' => 'बातचीत',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage' => 'मुख्य पृष्ठ',

);
