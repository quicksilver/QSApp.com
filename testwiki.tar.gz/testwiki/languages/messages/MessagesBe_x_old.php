<?php
/** Belarusian in Taraškievica orthography (Беларуская тарашкевіца)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment dummy language file. Falls back to 'be-tarask'. Backward compat.
 */

$fallback = 'be-tarask';
