<?php
/** Norfuk / Pitkern (Norfuk / Pitkern)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author http://pih.wikipedia.org sysops
 */

$messages = array(
# Dates
'january'      => 'Jaenyuweri',
'february'     => 'Febyuweri',
'march'        => 'Maach',
'april'        => 'Ieprel',
'may_long'     => 'Mieh',
'june'         => 'Juun',
'july'         => 'Juulai',
'january-gen'  => 'Jaenyuweri',
'february-gen' => 'Febyuweri',
'march-gen'    => 'Maach',
'april-gen'    => 'Ieprel',
'may-gen'      => 'Mieh',
'june-gen'     => 'Juun',
'july-gen'     => 'Juulai',
'may'          => 'Mieh',

'help'          => 'Hiiwp',
'history_short' => 'Histrei',
'edit'          => 'Edet',
'talk'          => 'diskushun',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'currentevents'        => 'Dem Kurent Iwent',
'currentevents-url'    => 'Project:Dem Kurent Iwent',
'helppage'             => 'Help:Dem Kontent',
'mainpage'             => 'Mien Paij',
'mainpage-description' => 'Mien Paij',
'portal'               => "Trii'nohlij",

'editold' => 'edet',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main' => 'Artikal',
'nstab-help' => 'Hiiwp Paij',

# Search results
'searchhelp-url' => 'Help:Dem Kontent',

# Preferences page
'prefs-rc' => 'Dem Riisent Chayng',

# Recent changes
'recentchanges' => 'Dem Riisent Chayng',

# Recent changes linked
'recentchangeslinked'         => 'Dem Riilated Chayng',
'recentchangeslinked-feed'    => 'Dem Riilated Chayng',
'recentchangeslinked-toolbox' => 'Dem Riilated Chayng',

# Upload
'upload' => 'Upload Faail',

# Random page
'randompage' => 'Raandum Paij',

# What links here
'whatlinkshere' => 'Wata link hiia',

);
