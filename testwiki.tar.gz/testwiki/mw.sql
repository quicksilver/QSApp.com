
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mw`
--

-- --------------------------------------------------------

--
-- Table structure for table `mw_archive`
--

CREATE TABLE `mw_archive` (
  `ar_namespace` int(11) NOT NULL DEFAULT '0',
  `ar_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `ar_text` mediumblob NOT NULL,
  `ar_comment` tinyblob NOT NULL,
  `ar_user` int(10) unsigned NOT NULL DEFAULT '0',
  `ar_user_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ar_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ar_minor_edit` tinyint(4) NOT NULL DEFAULT '0',
  `ar_flags` tinyblob NOT NULL,
  `ar_rev_id` int(10) unsigned DEFAULT NULL,
  `ar_text_id` int(10) unsigned DEFAULT NULL,
  `ar_deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ar_len` int(10) unsigned DEFAULT NULL,
  `ar_page_id` int(10) unsigned DEFAULT NULL,
  `ar_parent_id` int(10) unsigned DEFAULT NULL,
  KEY `name_title_timestamp` (`ar_namespace`,`ar_title`,`ar_timestamp`),
  KEY `usertext_timestamp` (`ar_user_text`,`ar_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_archive`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_category`
--

CREATE TABLE `mw_category` (
  `cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cat_pages` int(11) NOT NULL DEFAULT '0',
  `cat_subcats` int(11) NOT NULL DEFAULT '0',
  `cat_files` int(11) NOT NULL DEFAULT '0',
  `cat_hidden` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `cat_title` (`cat_title`),
  KEY `cat_pages` (`cat_pages`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_category`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_categorylinks`
--

CREATE TABLE `mw_categorylinks` (
  `cl_from` int(10) unsigned NOT NULL DEFAULT '0',
  `cl_to` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `cl_sortkey` varchar(70) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `cl_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `cl_from` (`cl_from`,`cl_to`),
  KEY `cl_sortkey` (`cl_to`,`cl_sortkey`,`cl_from`),
  KEY `cl_timestamp` (`cl_to`,`cl_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_categorylinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_change_tag`
--

CREATE TABLE `mw_change_tag` (
  `ct_rc_id` int(11) DEFAULT NULL,
  `ct_log_id` int(11) DEFAULT NULL,
  `ct_rev_id` int(11) DEFAULT NULL,
  `ct_tag` varchar(255) NOT NULL,
  `ct_params` blob,
  UNIQUE KEY `change_tag_rc_tag` (`ct_rc_id`,`ct_tag`),
  UNIQUE KEY `change_tag_log_tag` (`ct_log_id`,`ct_tag`),
  UNIQUE KEY `change_tag_rev_tag` (`ct_rev_id`,`ct_tag`),
  KEY `change_tag_tag_id` (`ct_tag`,`ct_rc_id`,`ct_rev_id`,`ct_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_change_tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_externallinks`
--

CREATE TABLE `mw_externallinks` (
  `el_from` int(10) unsigned NOT NULL DEFAULT '0',
  `el_to` blob NOT NULL,
  `el_index` blob NOT NULL,
  KEY `el_from` (`el_from`,`el_to`(40)),
  KEY `el_to` (`el_to`(60),`el_from`),
  KEY `el_index` (`el_index`(60))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_externallinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_external_user`
--

CREATE TABLE `mw_external_user` (
  `eu_local_id` int(10) unsigned NOT NULL,
  `eu_external_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`eu_local_id`),
  UNIQUE KEY `eu_external_id` (`eu_external_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_external_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_filearchive`
--

CREATE TABLE `mw_filearchive` (
  `fa_id` int(11) NOT NULL AUTO_INCREMENT,
  `fa_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `fa_archive_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '',
  `fa_storage_group` varbinary(16) DEFAULT NULL,
  `fa_storage_key` varbinary(64) DEFAULT '',
  `fa_deleted_user` int(11) DEFAULT NULL,
  `fa_deleted_timestamp` binary(14) DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `fa_deleted_reason` text,
  `fa_size` int(10) unsigned DEFAULT '0',
  `fa_width` int(11) DEFAULT '0',
  `fa_height` int(11) DEFAULT '0',
  `fa_metadata` mediumblob,
  `fa_bits` int(11) DEFAULT '0',
  `fa_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE') DEFAULT NULL,
  `fa_major_mime` enum('unknown','application','audio','image','text','video','message','model','multipart') DEFAULT 'unknown',
  `fa_minor_mime` varbinary(100) DEFAULT 'unknown',
  `fa_description` tinyblob,
  `fa_user` int(10) unsigned DEFAULT '0',
  `fa_user_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `fa_timestamp` binary(14) DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `fa_deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fa_id`),
  KEY `fa_name` (`fa_name`,`fa_timestamp`),
  KEY `fa_storage_group` (`fa_storage_group`,`fa_storage_key`),
  KEY `fa_deleted_timestamp` (`fa_deleted_timestamp`),
  KEY `fa_user_timestamp` (`fa_user_text`,`fa_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_filearchive`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_hitcounter`
--

CREATE TABLE `mw_hitcounter` (
  `hc_id` int(10) unsigned NOT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8 MAX_ROWS=25000;

--
-- Dumping data for table `mw_hitcounter`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_image`
--

CREATE TABLE `mw_image` (
  `img_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `img_size` int(10) unsigned NOT NULL DEFAULT '0',
  `img_width` int(11) NOT NULL DEFAULT '0',
  `img_height` int(11) NOT NULL DEFAULT '0',
  `img_metadata` mediumblob NOT NULL,
  `img_bits` int(11) NOT NULL DEFAULT '0',
  `img_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE') DEFAULT NULL,
  `img_major_mime` enum('unknown','application','audio','image','text','video','message','model','multipart') NOT NULL DEFAULT 'unknown',
  `img_minor_mime` varbinary(100) NOT NULL DEFAULT 'unknown',
  `img_description` tinyblob NOT NULL,
  `img_user` int(10) unsigned NOT NULL DEFAULT '0',
  `img_user_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `img_timestamp` varbinary(14) NOT NULL DEFAULT '',
  `img_sha1` varbinary(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`img_name`),
  KEY `img_usertext_timestamp` (`img_user_text`,`img_timestamp`),
  KEY `img_size` (`img_size`),
  KEY `img_timestamp` (`img_timestamp`),
  KEY `img_sha1` (`img_sha1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_image`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_imagelinks`
--

CREATE TABLE `mw_imagelinks` (
  `il_from` int(10) unsigned NOT NULL DEFAULT '0',
  `il_to` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  UNIQUE KEY `il_from` (`il_from`,`il_to`),
  UNIQUE KEY `il_to` (`il_to`,`il_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_imagelinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_interwiki`
--

CREATE TABLE `mw_interwiki` (
  `iw_prefix` varchar(32) NOT NULL,
  `iw_url` blob NOT NULL,
  `iw_local` tinyint(1) NOT NULL,
  `iw_trans` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `iw_prefix` (`iw_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_interwiki`
--

INSERT INTO `mw_interwiki` VALUES('acronym', 'http://www.acronymfinder.com/af-query.asp?String=exact&Acronym=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('advogato', 'http://www.advogato.org/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('annotationwiki', 'http://www.seedwiki.com/page.cfm?wikiid=368&doc=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('arxiv', 'http://www.arxiv.org/abs/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('c2find', 'http://c2.com/cgi/wiki?FindPage&value=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('cache', 'http://www.google.com/search?q=cache:$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('commons', 'http://commons.wikimedia.org/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('corpknowpedia', 'http://corpknowpedia.org/wiki/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('dictionary', 'http://www.dict.org/bin/Dict?Database=*&Form=Dict1&Strategy=*&Query=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('disinfopedia', 'http://www.disinfopedia.org/wiki.phtml?title=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('docbook', 'http://wiki.docbook.org/topic/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('doi', 'http://dx.doi.org/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('drumcorpswiki', 'http://www.drumcorpswiki.com/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('dwjwiki', 'http://www.suberic.net/cgi-bin/dwj/wiki.cgi?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('elibre', 'http://enciclopedia.us.es/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('emacswiki', 'http://www.emacswiki.org/cgi-bin/wiki.pl?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('foldoc', 'http://foldoc.org/?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('foxwiki', 'http://fox.wikis.com/wc.dll?Wiki~$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('freebsdman', 'http://www.FreeBSD.org/cgi/man.cgi?apropos=1&query=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('gej', 'http://www.esperanto.de/cgi-bin/aktivikio/wiki.pl?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('gentoo-wiki', 'http://gentoo-wiki.com/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('google', 'http://www.google.com/search?q=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('googlegroups', 'http://groups.google.com/groups?q=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('hammondwiki', 'http://www.dairiki.org/HammondWiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('hewikisource', 'http://he.wikisource.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('hrwiki', 'http://www.hrwiki.org/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('imdb', 'http://us.imdb.com/Title?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('jargonfile', 'http://sunir.org/apps/meta.pl?wiki=JargonFile&redirect=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('jspwiki', 'http://www.jspwiki.org/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('keiki', 'http://kei.ki/en/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('kmwiki', 'http://kmwiki.wikispaces.com/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('linuxwiki', 'http://linuxwiki.de/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('lojban', 'http://www.lojban.org/tiki/tiki-index.php?page=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('lqwiki', 'http://wiki.linuxquestions.org/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('lugkr', 'http://lug-kr.sourceforge.net/cgi-bin/lugwiki.pl?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('mathsongswiki', 'http://SeedWiki.com/page.cfm?wikiid=237&doc=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('meatball', 'http://www.usemod.com/cgi-bin/mb.pl?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('mediawikiwiki', 'http://www.mediawiki.org/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('mediazilla', 'https://bugzilla.wikimedia.org/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('memoryalpha', 'http://www.memory-alpha.org/en/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('metawiki', 'http://sunir.org/apps/meta.pl?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('metawikipedia', 'http://meta.wikimedia.org/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('moinmoin', 'http://purl.net/wiki/moin/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('mozillawiki', 'http://wiki.mozilla.org/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('mw', 'http://www.mediawiki.org/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('oeis', 'http://www.research.att.com/cgi-bin/access.cgi/as/njas/sequences/eisA.cgi?Anum=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('openfacts', 'http://openfacts.berlios.de/index.phtml?title=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('openwiki', 'http://openwiki.com/?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('patwiki', 'http://gauss.ffii.org/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('pmeg', 'http://www.bertilow.com/pmeg/$1.php', 0, 0);
INSERT INTO `mw_interwiki` VALUES('ppr', 'http://c2.com/cgi/wiki?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('pythoninfo', 'http://wiki.python.org/moin/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('rfc', 'http://www.rfc-editor.org/rfc/rfc$1.txt', 0, 0);
INSERT INTO `mw_interwiki` VALUES('s23wiki', 'http://is-root.de/wiki/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('seattlewiki', 'http://seattle.wikia.com/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('seattlewireless', 'http://seattlewireless.net/?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('senseislibrary', 'http://senseis.xmp.net/?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('slashdot', 'http://slashdot.org/article.pl?sid=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('sourceforge', 'http://sourceforge.net/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('squeak', 'http://wiki.squeak.org/squeak/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('susning', 'http://www.susning.nu/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('svgwiki', 'http://wiki.svg.org/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('tavi', 'http://tavi.sourceforge.net/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('tejo', 'http://www.tejo.org/vikio/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('theopedia', 'http://www.theopedia.com/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('tmbw', 'http://www.tmbw.net/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('tmnet', 'http://www.technomanifestos.net/?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('tmwiki', 'http://www.EasyTopicMaps.com/?page=$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('twiki', 'http://twiki.org/cgi-bin/view/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('uea', 'http://www.tejo.org/uea/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('unreal', 'http://wiki.beyondunreal.com/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('usemod', 'http://www.usemod.com/cgi-bin/wiki.pl?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('vinismo', 'http://vinismo.com/en/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('webseitzwiki', 'http://webseitz.fluxent.com/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('why', 'http://clublet.com/c/c/why?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wiki', 'http://c2.com/cgi/wiki?$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikia', 'http://www.wikia.com/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikibooks', 'http://en.wikibooks.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wikicities', 'http://www.wikia.com/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikif1', 'http://www.wikif1.org/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikihow', 'http://www.wikihow.com/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikimedia', 'http://wikimediafoundation.org/wiki/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikinews', 'http://en.wikinews.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wikinfo', 'http://www.wikinfo.org/index.php/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikipedia', 'http://en.wikipedia.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wikiquote', 'http://en.wikiquote.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wikisource', 'http://wikisource.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wikispecies', 'http://species.wikimedia.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wikitravel', 'http://wikitravel.org/en/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('wikiversity', 'http://en.wikiversity.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wikt', 'http://en.wiktionary.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wiktionary', 'http://en.wiktionary.org/wiki/$1', 1, 0);
INSERT INTO `mw_interwiki` VALUES('wlug', 'http://www.wlug.org.nz/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('zwiki', 'http://zwiki.org/$1', 0, 0);
INSERT INTO `mw_interwiki` VALUES('zzz wiki', 'http://wiki.zzz.ee/index.php/$1', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mw_ipblocks`
--

CREATE TABLE `mw_ipblocks` (
  `ipb_id` int(11) NOT NULL AUTO_INCREMENT,
  `ipb_address` tinyblob NOT NULL,
  `ipb_user` int(10) unsigned NOT NULL DEFAULT '0',
  `ipb_by` int(10) unsigned NOT NULL DEFAULT '0',
  `ipb_by_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `ipb_reason` tinyblob NOT NULL,
  `ipb_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ipb_auto` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_anon_only` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_create_account` tinyint(1) NOT NULL DEFAULT '1',
  `ipb_enable_autoblock` tinyint(1) NOT NULL DEFAULT '1',
  `ipb_expiry` varbinary(14) NOT NULL DEFAULT '',
  `ipb_range_start` tinyblob NOT NULL,
  `ipb_range_end` tinyblob NOT NULL,
  `ipb_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_block_email` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_allow_usertalk` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ipb_id`),
  UNIQUE KEY `ipb_address` (`ipb_address`(255),`ipb_user`,`ipb_auto`,`ipb_anon_only`),
  KEY `ipb_user` (`ipb_user`),
  KEY `ipb_range` (`ipb_range_start`(8),`ipb_range_end`(8)),
  KEY `ipb_timestamp` (`ipb_timestamp`),
  KEY `ipb_expiry` (`ipb_expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_ipblocks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_job`
--

CREATE TABLE `mw_job` (
  `job_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_cmd` varbinary(60) NOT NULL DEFAULT '',
  `job_namespace` int(11) NOT NULL,
  `job_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `job_params` blob NOT NULL,
  PRIMARY KEY (`job_id`),
  KEY `job_cmd` (`job_cmd`,`job_namespace`,`job_title`,`job_params`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_job`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_l10n_cache`
--

CREATE TABLE `mw_l10n_cache` (
  `lc_lang` varbinary(32) NOT NULL,
  `lc_key` varchar(255) NOT NULL,
  `lc_value` mediumblob NOT NULL,
  KEY `lc_lang_key` (`lc_lang`,`lc_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_l10n_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_langlinks`
--

CREATE TABLE `mw_langlinks` (
  `ll_from` int(10) unsigned NOT NULL DEFAULT '0',
  `ll_lang` varbinary(20) NOT NULL DEFAULT '',
  `ll_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  UNIQUE KEY `ll_from` (`ll_from`,`ll_lang`),
  KEY `ll_lang` (`ll_lang`,`ll_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_langlinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_logging`
--

CREATE TABLE `mw_logging` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varbinary(32) NOT NULL DEFAULT '',
  `log_action` varbinary(32) NOT NULL DEFAULT '',
  `log_timestamp` binary(14) NOT NULL DEFAULT '19700101000000',
  `log_user` int(10) unsigned NOT NULL DEFAULT '0',
  `log_user_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `log_namespace` int(11) NOT NULL DEFAULT '0',
  `log_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `log_page` int(10) unsigned DEFAULT NULL,
  `log_comment` varchar(255) NOT NULL DEFAULT '',
  `log_params` blob NOT NULL,
  `log_deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `type_time` (`log_type`,`log_timestamp`),
  KEY `user_time` (`log_user`,`log_timestamp`),
  KEY `page_time` (`log_namespace`,`log_title`,`log_timestamp`),
  KEY `times` (`log_timestamp`),
  KEY `log_user_type_time` (`log_user`,`log_type`,`log_timestamp`),
  KEY `log_page_id_time` (`log_page`,`log_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_logging`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_log_search`
--

CREATE TABLE `mw_log_search` (
  `ls_field` varbinary(32) NOT NULL,
  `ls_value` varchar(255) NOT NULL,
  `ls_log_id` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `ls_field_val` (`ls_field`,`ls_value`,`ls_log_id`),
  KEY `ls_log_id` (`ls_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_log_search`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_math`
--

CREATE TABLE `mw_math` (
  `math_inputhash` varbinary(16) NOT NULL,
  `math_outputhash` varbinary(16) NOT NULL,
  `math_html_conservativeness` tinyint(4) NOT NULL,
  `math_html` text,
  `math_mathml` text,
  UNIQUE KEY `math_inputhash` (`math_inputhash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_math`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_objectcache`
--

CREATE TABLE `mw_objectcache` (
  `keyname` varbinary(255) NOT NULL DEFAULT '',
  `value` mediumblob,
  `exptime` datetime DEFAULT NULL,
  PRIMARY KEY (`keyname`),
  KEY `exptime` (`exptime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_objectcache`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_oldimage`
--

CREATE TABLE `mw_oldimage` (
  `oi_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `oi_archive_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `oi_size` int(10) unsigned NOT NULL DEFAULT '0',
  `oi_width` int(11) NOT NULL DEFAULT '0',
  `oi_height` int(11) NOT NULL DEFAULT '0',
  `oi_bits` int(11) NOT NULL DEFAULT '0',
  `oi_description` tinyblob NOT NULL,
  `oi_user` int(10) unsigned NOT NULL DEFAULT '0',
  `oi_user_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `oi_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `oi_metadata` mediumblob NOT NULL,
  `oi_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE') DEFAULT NULL,
  `oi_major_mime` enum('unknown','application','audio','image','text','video','message','model','multipart') NOT NULL DEFAULT 'unknown',
  `oi_minor_mime` varbinary(100) NOT NULL DEFAULT 'unknown',
  `oi_deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `oi_sha1` varbinary(32) NOT NULL DEFAULT '',
  KEY `oi_usertext_timestamp` (`oi_user_text`,`oi_timestamp`),
  KEY `oi_name_timestamp` (`oi_name`,`oi_timestamp`),
  KEY `oi_name_archive_name` (`oi_name`,`oi_archive_name`(14)),
  KEY `oi_sha1` (`oi_sha1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_oldimage`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_page`
--

CREATE TABLE `mw_page` (
  `page_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_namespace` int(11) NOT NULL,
  `page_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `page_restrictions` tinyblob NOT NULL,
  `page_counter` bigint(20) unsigned NOT NULL DEFAULT '0',
  `page_is_redirect` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `page_is_new` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `page_random` double unsigned NOT NULL,
  `page_touched` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `page_latest` int(10) unsigned NOT NULL,
  `page_len` int(10) unsigned NOT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `name_title` (`page_namespace`,`page_title`),
  KEY `page_random` (`page_random`),
  KEY `page_len` (`page_len`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mw_page`
--

INSERT INTO `mw_page` VALUES(1, 0, 'Main_Page', '', 0, 0, 0, 0.436301127232, '20110402224009', 1, 438);

-- --------------------------------------------------------

--
-- Table structure for table `mw_pagelinks`
--

CREATE TABLE `mw_pagelinks` (
  `pl_from` int(10) unsigned NOT NULL DEFAULT '0',
  `pl_namespace` int(11) NOT NULL DEFAULT '0',
  `pl_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  UNIQUE KEY `pl_from` (`pl_from`,`pl_namespace`,`pl_title`),
  UNIQUE KEY `pl_namespace` (`pl_namespace`,`pl_title`,`pl_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_pagelinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_page_props`
--

CREATE TABLE `mw_page_props` (
  `pp_page` int(11) NOT NULL,
  `pp_propname` varbinary(60) NOT NULL,
  `pp_value` blob NOT NULL,
  UNIQUE KEY `pp_page_propname` (`pp_page`,`pp_propname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_page_props`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_page_restrictions`
--

CREATE TABLE `mw_page_restrictions` (
  `pr_page` int(11) NOT NULL,
  `pr_type` varbinary(60) NOT NULL,
  `pr_level` varbinary(60) NOT NULL,
  `pr_cascade` tinyint(4) NOT NULL,
  `pr_user` int(11) DEFAULT NULL,
  `pr_expiry` varbinary(14) DEFAULT NULL,
  `pr_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`pr_id`),
  UNIQUE KEY `pr_pagetype` (`pr_page`,`pr_type`),
  KEY `pr_typelevel` (`pr_type`,`pr_level`),
  KEY `pr_level` (`pr_level`),
  KEY `pr_cascade` (`pr_cascade`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_page_restrictions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_protected_titles`
--

CREATE TABLE `mw_protected_titles` (
  `pt_namespace` int(11) NOT NULL,
  `pt_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `pt_user` int(10) unsigned NOT NULL,
  `pt_reason` tinyblob,
  `pt_timestamp` binary(14) NOT NULL,
  `pt_expiry` varbinary(14) NOT NULL DEFAULT '',
  `pt_create_perm` varbinary(60) NOT NULL,
  UNIQUE KEY `pt_namespace_title` (`pt_namespace`,`pt_title`),
  KEY `pt_timestamp` (`pt_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_protected_titles`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_querycache`
--

CREATE TABLE `mw_querycache` (
  `qc_type` varbinary(32) NOT NULL,
  `qc_value` int(10) unsigned NOT NULL DEFAULT '0',
  `qc_namespace` int(11) NOT NULL DEFAULT '0',
  `qc_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  KEY `qc_type` (`qc_type`,`qc_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_querycache`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_querycachetwo`
--

CREATE TABLE `mw_querycachetwo` (
  `qcc_type` varbinary(32) NOT NULL,
  `qcc_value` int(10) unsigned NOT NULL DEFAULT '0',
  `qcc_namespace` int(11) NOT NULL DEFAULT '0',
  `qcc_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `qcc_namespacetwo` int(11) NOT NULL DEFAULT '0',
  `qcc_titletwo` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  KEY `qcc_type` (`qcc_type`,`qcc_value`),
  KEY `qcc_title` (`qcc_type`,`qcc_namespace`,`qcc_title`),
  KEY `qcc_titletwo` (`qcc_type`,`qcc_namespacetwo`,`qcc_titletwo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_querycachetwo`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_querycache_info`
--

CREATE TABLE `mw_querycache_info` (
  `qci_type` varbinary(32) NOT NULL DEFAULT '',
  `qci_timestamp` binary(14) NOT NULL DEFAULT '19700101000000',
  UNIQUE KEY `qci_type` (`qci_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_querycache_info`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_recentchanges`
--

CREATE TABLE `mw_recentchanges` (
  `rc_id` int(11) NOT NULL AUTO_INCREMENT,
  `rc_timestamp` varbinary(14) NOT NULL DEFAULT '',
  `rc_cur_time` varbinary(14) NOT NULL DEFAULT '',
  `rc_user` int(10) unsigned NOT NULL DEFAULT '0',
  `rc_user_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `rc_namespace` int(11) NOT NULL DEFAULT '0',
  `rc_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `rc_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `rc_minor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rc_bot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rc_new` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rc_cur_id` int(10) unsigned NOT NULL DEFAULT '0',
  `rc_this_oldid` int(10) unsigned NOT NULL DEFAULT '0',
  `rc_last_oldid` int(10) unsigned NOT NULL DEFAULT '0',
  `rc_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rc_moved_to_ns` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rc_moved_to_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `rc_patrolled` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rc_ip` varbinary(40) NOT NULL DEFAULT '',
  `rc_old_len` int(11) DEFAULT NULL,
  `rc_new_len` int(11) DEFAULT NULL,
  `rc_deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rc_logid` int(10) unsigned NOT NULL DEFAULT '0',
  `rc_log_type` varbinary(255) DEFAULT NULL,
  `rc_log_action` varbinary(255) DEFAULT NULL,
  `rc_params` blob,
  PRIMARY KEY (`rc_id`),
  KEY `rc_timestamp` (`rc_timestamp`),
  KEY `rc_namespace_title` (`rc_namespace`,`rc_title`),
  KEY `rc_cur_id` (`rc_cur_id`),
  KEY `new_name_timestamp` (`rc_new`,`rc_namespace`,`rc_timestamp`),
  KEY `rc_ip` (`rc_ip`),
  KEY `rc_ns_usertext` (`rc_namespace`,`rc_user_text`),
  KEY `rc_user_text` (`rc_user_text`,`rc_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_recentchanges`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_redirect`
--

CREATE TABLE `mw_redirect` (
  `rd_from` int(10) unsigned NOT NULL DEFAULT '0',
  `rd_namespace` int(11) NOT NULL DEFAULT '0',
  `rd_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `rd_interwiki` varchar(32) DEFAULT NULL,
  `rd_fragment` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`rd_from`),
  KEY `rd_ns_title` (`rd_namespace`,`rd_title`,`rd_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_redirect`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_revision`
--

CREATE TABLE `mw_revision` (
  `rev_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rev_page` int(10) unsigned NOT NULL,
  `rev_text_id` int(10) unsigned NOT NULL,
  `rev_comment` tinyblob NOT NULL,
  `rev_user` int(10) unsigned NOT NULL DEFAULT '0',
  `rev_user_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `rev_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `rev_minor_edit` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rev_deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rev_len` int(10) unsigned DEFAULT NULL,
  `rev_parent_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`rev_id`),
  UNIQUE KEY `rev_page_id` (`rev_page`,`rev_id`),
  KEY `rev_timestamp` (`rev_timestamp`),
  KEY `page_timestamp` (`rev_page`,`rev_timestamp`),
  KEY `user_timestamp` (`rev_user`,`rev_timestamp`),
  KEY `usertext_timestamp` (`rev_user_text`,`rev_timestamp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 MAX_ROWS=10000000 AVG_ROW_LENGTH=1024 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mw_revision`
--

INSERT INTO `mw_revision` VALUES(1, 1, 1, '', 0, 'MediaWiki default', '20110402224009', 0, 0, 438, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mw_searchindex`
--

CREATE TABLE `mw_searchindex` (
  `si_page` int(10) unsigned NOT NULL,
  `si_title` varchar(255) NOT NULL DEFAULT '',
  `si_text` mediumtext NOT NULL,
  UNIQUE KEY `si_page` (`si_page`),
  FULLTEXT KEY `si_title` (`si_title`),
  FULLTEXT KEY `si_text` (`si_text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_searchindex`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_site_stats`
--

CREATE TABLE `mw_site_stats` (
  `ss_row_id` int(10) unsigned NOT NULL,
  `ss_total_views` bigint(20) unsigned DEFAULT '0',
  `ss_total_edits` bigint(20) unsigned DEFAULT '0',
  `ss_good_articles` bigint(20) unsigned DEFAULT '0',
  `ss_total_pages` bigint(20) DEFAULT '-1',
  `ss_users` bigint(20) DEFAULT '-1',
  `ss_active_users` bigint(20) DEFAULT '-1',
  `ss_admins` int(11) DEFAULT '-1',
  `ss_images` int(11) DEFAULT '0',
  UNIQUE KEY `ss_row_id` (`ss_row_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_site_stats`
--

INSERT INTO `mw_site_stats` VALUES(1, 0, 1, 0, 1, 1, -1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mw_tag_summary`
--

CREATE TABLE `mw_tag_summary` (
  `ts_rc_id` int(11) DEFAULT NULL,
  `ts_log_id` int(11) DEFAULT NULL,
  `ts_rev_id` int(11) DEFAULT NULL,
  `ts_tags` blob NOT NULL,
  UNIQUE KEY `tag_summary_rc_id` (`ts_rc_id`),
  UNIQUE KEY `tag_summary_log_id` (`ts_log_id`),
  UNIQUE KEY `tag_summary_rev_id` (`ts_rev_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_tag_summary`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_templatelinks`
--

CREATE TABLE `mw_templatelinks` (
  `tl_from` int(10) unsigned NOT NULL DEFAULT '0',
  `tl_namespace` int(11) NOT NULL DEFAULT '0',
  `tl_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  UNIQUE KEY `tl_from` (`tl_from`,`tl_namespace`,`tl_title`),
  UNIQUE KEY `tl_namespace` (`tl_namespace`,`tl_title`,`tl_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_templatelinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_text`
--

CREATE TABLE `mw_text` (
  `old_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_text` mediumblob NOT NULL,
  `old_flags` tinyblob NOT NULL,
  PRIMARY KEY (`old_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 MAX_ROWS=10000000 AVG_ROW_LENGTH=10240 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mw_text`
--

INSERT INTO `mw_text` VALUES(1, '''''''MediaWiki has been successfully installed.''''''\n\nConsult the [http://meta.wikimedia.org/wiki/Help:Contents User''s Guide] for information on using the wiki software.\n\n== Getting started ==\n* [http://www.mediawiki.org/wiki/Manual:Configuration_settings Configuration settings list]\n* [http://www.mediawiki.org/wiki/Manual:FAQ MediaWiki FAQ]\n* [https://lists.wikimedia.org/mailman/listinfo/mediawiki-announce MediaWiki release mailing list]', 'utf-8');

-- --------------------------------------------------------

--
-- Table structure for table `mw_trackbacks`
--

CREATE TABLE `mw_trackbacks` (
  `tb_id` int(11) NOT NULL AUTO_INCREMENT,
  `tb_page` int(11) DEFAULT NULL,
  `tb_title` varchar(255) NOT NULL,
  `tb_url` blob NOT NULL,
  `tb_ex` text,
  `tb_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tb_id`),
  KEY `tb_page` (`tb_page`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mw_trackbacks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_transcache`
--

CREATE TABLE `mw_transcache` (
  `tc_url` varbinary(255) NOT NULL,
  `tc_contents` text,
  `tc_time` binary(14) NOT NULL,
  UNIQUE KEY `tc_url_idx` (`tc_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_transcache`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_updatelog`
--

CREATE TABLE `mw_updatelog` (
  `ul_key` varchar(255) NOT NULL,
  PRIMARY KEY (`ul_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_updatelog`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_user`
--

CREATE TABLE `mw_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_real_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_password` tinyblob NOT NULL,
  `user_newpassword` tinyblob NOT NULL,
  `user_newpass_time` binary(14) DEFAULT NULL,
  `user_email` tinytext NOT NULL,
  `user_options` blob NOT NULL,
  `user_touched` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `user_token` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `user_email_authenticated` binary(14) DEFAULT NULL,
  `user_email_token` binary(32) DEFAULT NULL,
  `user_email_token_expires` binary(14) DEFAULT NULL,
  `user_registration` binary(14) DEFAULT NULL,
  `user_editcount` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `user_email_token` (`user_email_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mw_user`
--

INSERT INTO `mw_user` VALUES(1, 'Patrick', '', ':B:8m1e6umt:b5bdac3abeebe32c71aec3c7bf795407', '', NULL, 'patrick@qsapp.com', '', '20110402224009', 'cxqdnyvramznvjjbxs3sxwairbx2jfzy', NULL, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', NULL, '20110402224009', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mw_user_groups`
--

CREATE TABLE `mw_user_groups` (
  `ug_user` int(10) unsigned NOT NULL DEFAULT '0',
  `ug_group` varbinary(16) NOT NULL DEFAULT '',
  UNIQUE KEY `ug_user_group` (`ug_user`,`ug_group`),
  KEY `ug_group` (`ug_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_user_groups`
--

INSERT INTO `mw_user_groups` VALUES(1, 'bureaucrat');
INSERT INTO `mw_user_groups` VALUES(1, 'sysop');

-- --------------------------------------------------------

--
-- Table structure for table `mw_user_newtalk`
--

CREATE TABLE `mw_user_newtalk` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_ip` varbinary(40) NOT NULL DEFAULT '',
  `user_last_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  KEY `user_id` (`user_id`),
  KEY `user_ip` (`user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_user_newtalk`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_user_properties`
--

CREATE TABLE `mw_user_properties` (
  `up_user` int(11) NOT NULL,
  `up_property` varbinary(32) NOT NULL,
  `up_value` blob,
  UNIQUE KEY `user_properties_user_property` (`up_user`,`up_property`),
  KEY `user_properties_property` (`up_property`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_user_properties`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_valid_tag`
--

CREATE TABLE `mw_valid_tag` (
  `vt_tag` varchar(255) NOT NULL,
  PRIMARY KEY (`vt_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_valid_tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `mw_watchlist`
--

CREATE TABLE `mw_watchlist` (
  `wl_user` int(10) unsigned NOT NULL,
  `wl_namespace` int(11) NOT NULL DEFAULT '0',
  `wl_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `wl_notificationtimestamp` varbinary(14) DEFAULT NULL,
  UNIQUE KEY `wl_user` (`wl_user`,`wl_namespace`,`wl_title`),
  KEY `namespace_title` (`wl_namespace`,`wl_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mw_watchlist`
--

